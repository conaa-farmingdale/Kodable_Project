/****************************************************************************
   This is the group project for team StruggleBus.
 
    This program is for a game that teaches a beginner how to code.
 ****************************************************************************
 */

import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;  


public class DriverClass extends Application{
	

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		// Rectangles for background
		Rectangle bg1 = new Rectangle (1000,800);
		bg1.setFill(Color.LIMEGREEN);
	
		Rectangle bg2 = new Rectangle (1000,150);
		bg2.setFill(Color.BROWN);			
		bg2.setStroke(Color.FIREBRICK);
		
			//Spokes - main character image
			Image spokesImg=new Image("Spokes2.png");
			ImageView spokes=new ImageView(spokesImg);
			//controller arrow buttons
			Image upArrowImg=new Image("UpArrowBtn.jpg");
			ImageView upArrow=new ImageView(upArrowImg);
			Image downArrowImg=new Image("DownArrowBtn.jpg");
			ImageView downArrow=new ImageView(downArrowImg);
			Image rightArrowImg=new Image("RightArrowBtn.jpg");
			ImageView rightArrow=new ImageView(rightArrowImg);
			Image leftArrowImg=new Image("LeftArrowBtn.jpg");
			ImageView leftArrow=new ImageView(leftArrowImg);
			
			// hBox for arrow controls
			HBox arrowControlHBox = new HBox(upArrow, downArrow, rightArrow, leftArrow);
			arrowControlHBox.setAlignment(Pos.TOP_LEFT);
			
						
			// Squares for character path
			Rectangle square1 = new Rectangle (5,380,150,150);
			square1.setFill(Color.GREY);
			Rectangle square2 = new Rectangle (155,380,150,150);
			square2.setFill(Color.GREY);
			Rectangle square3 = new Rectangle (305,380,150,150);
			square3.setFill(Color.GREY);
			Rectangle square4 = new Rectangle (305,230,150,150);
			square4.setFill(Color.GREY);
			Rectangle square5 = new Rectangle (455,230,150,150);
			square5.setFill(Color.GREY);
			Rectangle square6 = new Rectangle (605,230,150,150);
			square6.setFill(Color.GREY);
			Rectangle square7 = new Rectangle (755,230,150,150);
			square7.setFill(Color.GREY);
			
			Group grp = new Group(bg1, bg2,arrowControlHBox,square1, square2, square3, square4, square5, square6, square7, spokes);
		
			Scene sn = new Scene(grp, 900,900);
			sn.getStylesheets().add("mystyle.css");
			primaryStage.setScene(sn);
			primaryStage.show();
			
			/* Start the game by displaying the character and moving
			   it to the middle left position.*/
			
			RotateTransition rt=new RotateTransition(new Duration(2000), spokes);
			TranslateTransition tt=new TranslateTransition(new Duration(2000), spokes);
			tt.setFromX(10);tt.setFromY(200);
			tt.setToX(10);tt.setToY(400);
			rt.setFromAngle(0);;
			rt.setToAngle(1080);
			rt.setCycleCount(1);		
					
			rt.play();
			tt.play();
		
	}	


	  


		public static void main(String[] args) {
			launch (args);
		}
}

