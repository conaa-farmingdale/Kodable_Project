

	import javafx.fxml.FXML;
	import javafx.scene.control.Separator;
	import javafx.scene.layout.HBox;

	public class Level1Screen1Controller {

	    @FXML
	    private HBox mL1S1UserPathhBox;

	    @FXML
	    private HBox mL1S1UserControlshBox;

	    @FXML
	    private Separator mL1S1TopSeparatorLeft1;

	    @FXML
	    private HBox mL1S1PlayControlhBox;

	    @FXML
	    private Separator mL1S1TopSeparatorLeft;

	}



